/*
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class ButtonMoveApplet extends Applet 
{
    public void init(){
        
    }
    public void paint(Graphics g)
    {
         setBackground(Color.pink);
         setForeground(Color.black);
         g.drawString("Welcome JSP-APPLET",100,100);
     }
}

